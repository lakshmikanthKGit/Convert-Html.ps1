﻿#requires -version 3.0

#here's another way to do conditional formatting
#step through this in the ISE

#remove any variables from last example
Remove-Variable html

$computername = $env:COMPUTERNAME

#save current location so I can set it back after importing SQL module
$curr = get-location

#import the SQL Server 2012 PowerShell Module
Import-Module SQLPS

#change the location back
set-location $curr

#path to databases
$dbpath = "SQLServer:\SQL\Localhost\default\databases"

#for the sake of my demo I only want to get db information once
$dbs = dir $dbpath

#plain data
$dbs | Select Name,Size,DataSpaceUsage,SpaceAvailable,
@{Name="PercentFree";Expression={ [math]::Round((($_.SpaceAvailable/1kb)/$_.size)*100,2)}} | 
Sort PercentFree | 
format-table -AutoSize

<#
 < 10% = danger
 < 20% = warn
#>

#lets insert a graphic as well
$imagefile = "c:\scripts\db.png"
$ImageBits = [Convert]::ToBase64String((Get-Content $imagefile -Encoding Byte))
$ImageHTML = "<img src=data:image/png;base64,$($ImageBits) alt='db utilization'/>"

#embed the style, image and title in the html header
$head = @"
<Title>Database Utilization Report</Title>
<style>
body 
{ 
 background-color:#FFFFFF;
 font-family:Arial;
 font-size:12pt; 
}
td, th 
{ 
 border:1px solid black; 
 border-collapse:collapse; 
}
th 
{
 color:white;
 background-color:gray; 
}
table, tr, td, th { padding: 5px; margin: 0px }
table { margin-left:50px; }
.danger {background-color: red}
.warn {background-color: yellow}
img
{
float:left;
margin: 0px 25px;
}
</style>
$imagehtml
<br><br><br>
<H2>Database Utilization on $Computername</H2>
<br><br><br>
"@

[xml]$html = $dbs | Select Name,Size,DataSpaceUsage,SpaceAvailable,
@{Name="PercentFree";Expression={ [math]::Round((($_.SpaceAvailable/1kb)/$_.size)*100,2) }} | 
ConvertTo-HTML -fragment

#check each row, skipping the TH header row
for ($i=1;$i -le $html.table.tr.count-1;$i++) {
  $class = $html.CreateAttribute("class")
  #check the value of the last column and assign a class to the row
  if (($html.table.tr[$i].td[-1] -as [int]) -le 10) {                                          
    $class.value = "danger"  
    $html.table.tr[$i].Attributes.Append($class) | Out-Null
  }
  elseif (($html.table.tr[$i].td[-1] -as [int]) -le 20) {                                               
    $class.value = "warn"    
    $html.table.tr[$i].Attributes.Append($class) | Out-Null
  }
}

#create the final report from the innerxml which should be html code
$body = @"
$($html.innerxml)
"@

#check out the html
$body

#create the HTML file
ConvertTo-HTML -head $head -PostContent "<br><i>$(Get-date)</i>" -body $body | 
Out-File "$env:temp\dbusage.htm" -Encoding ascii

#view it
Invoke-Item "$env:temp\dbusage.htm"