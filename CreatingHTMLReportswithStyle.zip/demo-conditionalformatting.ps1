﻿#requires -version 3.0

#here's another way to handle conditional formatting
#this can be run as a standalone script
$computername = $env:COMPUTERNAME

$data = Get-CimInstance win32_volume -filter "drivetype=3" -ComputerName $computername

$drives = foreach ($item in $data) {
    $prophash = [ordered]@{
    Drive = $item.DriveLetter
    Volume = $item.DeviceID
    Compressed = $item.Compressed
    SizeGB = $item.capacity/1GB -as [int]
    FreeGB = "{0:N4}" -f ($item.Freespace/1GB )
    PercentFree = [math]::Round((($item.Freespace/$item.capacity) * 100),2)
    }

    #create a new object from the property hash
    New-Object PSObject -Property $prophash
}

#embed the style in the html header
$head = @'
<Title>Volume Report</Title>
<style>
body 
{ 
 background-color:#FFFFFF;
 font-family:Tahoma;
 font-size:12pt; 
}
td, th 
{ 
 border:1px solid black; 
 border-collapse:collapse; 
}
th 
{
 color:white;
 background-color:black; 
}
table, tr, td, th { padding: 5px; margin: 0px }
table { margin-left:50px; }
.danger {background-color: red}
.warn {background-color: yellow}
</style>
'@

#create an xml document from the HTML fragment
[xml]$html = $drives | ConvertTo-Html -fragment

#check each row, skipping the TH header row
for ($i=1;$i -le $html.table.tr.count-1;$i++) {
  $class = $html.CreateAttribute("class")
  #check the value of the last column and assign a class to the row
  if (($html.table.tr[$i].td[-1] -as [int]) -le 25) {                                          
    $class.value = "danger"  
    $html.table.tr[$i].Attributes.Append($class) | Out-Null
  }
  elseif (($html.table.tr[$i].td[-1] -as [int]) -le 30) {                                               
    $class.value = "warn"    
    $html.table.tr[$i].Attributes.Append($class) | Out-Null
  }
}

#create the final report from the innerxml which should be html code
$body = @"
<H1>Volume Utilization for $Computername</H1>
$($html.innerxml)
"@

#put it all together
ConvertTo-HTML -head $head  -PostContent "<br><i>$(Get-date)</i>" -body $body | 
Out-File "$env:temp\drives.htm" -Encoding ascii

Invoke-Item "$env:temp\drives.htm"