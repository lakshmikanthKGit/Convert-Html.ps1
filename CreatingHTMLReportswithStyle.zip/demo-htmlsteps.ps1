﻿#requires -version 3.0

#demo each region interactively

#these are typical IT Pro examples
$computername = $env:COMPUTERNAME

#region Start with good data

$data = Get-Ciminstance Win32_Service -ComputerName $computername | 
Select Name,Displayname,State,StartMode

#view the data
$data

#endregion

#region A simple report using an external style sheet

#here's my style sheet
psedit c:\scripts\blue.css

#the name of the file to create
$file = Join-Path $env:temp "basic.htm"

#take the data and convert to html using the style sheet
$data | 
ConvertTo-Html -Title "$computername Service Report" `
-CssUri c:\scripts\blue.css `
-pre "<h2>$computername</h2>" `
-post "<br><I>$(get-date)</I>" |
Out-file $file -Encoding ascii

#view the resulting file
Invoke-Item $file

#endregion

#region use fragments

$fragments="<h2>$computername</h2>"

$data | group startmode | foreach {
    $fragments+="<H3>$($_.Name) ($($_.Count))</H3>"
    $fragments+= $_.Group | ConvertTo-Html -Fragment
 }

ConvertTo-html -Title "$computername Service Status" `
-Body $fragments `
-post "<br><I>$(get-date)</I>" `
-Head "<style>$(get-content c:\scripts\blue.css)</style>" | 
Out-File $file

#view the resulting file
Invoke-Item $file

#endregion

#region parse html for conditional formatting

$fragments= "<h2>$computername</h2>"
$fragments+= $data | ConvertTo-Html -Fragment

#fragments is just text
$fragments 

#find all stopped services that should be running and change
#the font color to red
$revised = $fragments -replace "<td>Stopped</td><td>Auto</td>","<td style='color:red'>Stopped</td><td>Auto</td>"

#I'm going to use a CSS file with these conditions
#assuming this is being run from the ISE
psedit c:\scripts\sample.css

ConvertTo-html -Title "$computername Service Status" `
-Body $revised `
-post "<br><I>$(get-date)</I>" `
-Head "<style>$(get-content c:\scripts\sample.css)</style>" | 
Out-File $file

#view the resulting file
Invoke-Item $file

#endregion
